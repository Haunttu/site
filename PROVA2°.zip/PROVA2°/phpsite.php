<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = htmlspecialchars($_POST['nome']);
    $cpf = htmlspecialchars($_POST['cpf']);
    $email = htmlspecialchars($_POST['email']);
    $telefone = htmlspecialchars($_POST['telefone']);
    $endereco = htmlspecialchars($_POST['endereco']);

    // Cria uma string para os dados serem passados no arquivo txt
    $dados = "Nome: $nome\nCPF: $cpf\nEmail: $email\nTelefone: $telefone\nEndereço: $endereco\n\n";

    // Especifica o nome do arquivo
    $arquivo = 'cadastros.txt';

    // Abre o arquivo para escrita e cria se n existir
    $handle = fopen($arquivo, 'a');

    // Verifica se o arquivo foi aberto
    if ($handle) {
        // Escreve os dados no arquivo
        fwrite($handle, $dados);

        // Fecha o arquivo
        fclose($handle);

        // Mensagem usando java, redirecionar para a pag principal.
        echo "<script>
            alert('Obrigado por se cadastrar! Seus dados foram salvos com sucesso.');
            window.location.href = 'index666.html'; // Redireciona para a página principal
        </script>";
    } else {
        // Exibe uma mensagem de erro caso n seja possivel salvar os dados
        echo "Não foi possível salvar os dados.";
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>

<style>
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body{
    background-color:#c2c2c2;
    height: 100vh;
}

h2.titulo{
    color: black;
    font-size: 38px;
    padding-top: 60px;
    text-align: center;
}

h2.titulo span{/* o span do texto */
    color:#dc143c;
}


body {
    background-image: url('telafundo.png'); /* Substitua 'caminho/da/sua/imagem.jpg' pelo caminho para a sua imagem */
    background-size: cover; /* Garante que a imagem cubra todo o corpo */
    background-position: center; /* Centraliza a imagem no corpo */
}


/*estilo do formulario---------------------*/

section.formulario{
    padding: 40px 4%;
}

form{
    max-width: 500px;
    margin: 0 auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
    gap: 10px;
    margin-top: 40px;
}

form input, form textarea {/* cor,espaço, estilisação dos retangulos de digitação e a font da escrita. */
    width: 100%;
    background-color: #242424;
    border: 0;
    outline: 0;
    padding: 20px 15px;
    color: white;
    border-radius: 15px;
    font-size: 15px;
}

form input::placeholder{/* cor das letras antes de escrever os dados no formulario */
    color: #c2c2c2;
}

form textarea{
    resize: none;
    max-height: 180px;
}
/* configuração botao--------------------*/
form .btn-enviar{
    margin-top: 20px;
    text-align: center;
}

form .btn-enviar input{
    width: 120px;
    background-color: #dc143c;
    color:black;
    font-weight: 700;
    cursor: pointer;
}

form .btn-enviar input:hover{
    box-shadow: 0px 0px 8px #00ffff;
    transform: scale(1.07);
    transition: 1s;
}




</style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CADASTRO</title>
</head>
<body>
    <section class="formulario">
        <div class="interface">
            <h2 class="titulo">FAÇA SUA INSCRIÇÃO<span>!</span></h2> 
            <form action="#" method="POST">
                <input type="text" name="nome" placeholder="Seu nome completo:" required>
                <input type="text" name="cpf" placeholder="CPF:" required>
                <input type="email" name="email" placeholder="Seu email:" required>
                <input type="text" name="telefone" placeholder="Seu telefone:" required>
                <input type="text" name="endereco" placeholder="Seu endereço:">                
                <div class="btn-enviar"><input type="submit" value="ENVIAR"></div>
            </form>
        </div>
    </section>
</body>
</html>