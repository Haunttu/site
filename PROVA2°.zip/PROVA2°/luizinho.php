<?php
// Verifica se o arquivo de cadastros existe
$arquivo = 'cadastros.txt';
$conteudo = '';

if (file_exists($arquivo)) {
    // Lê o conteúdo do arquivo
    $conteudo = file_get_contents($arquivo);
} else {
    $conteudo = 'Nenhum cadastro encontrado.';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exibir Cadastros</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        pre {
            text-align: left;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            overflow: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Cadastros Realizados</h2>
        <pre><?php echo htmlspecialchars($conteudo); ?></pre>
    </div>
</body>
</html>
